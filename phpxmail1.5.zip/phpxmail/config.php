<?php

	//allow crossdomain aliases
	$cfg_allow_cross_alias='off';

	//allow ADMIN info in login page
	$cfg_allow_admin_info='on';

	// show stats in userlist
	$cfg_userlist_stat='on';

	// show stats in uservars
	$cfg_uservars_stat='on';

	//turn debugging on/off
	$cfg_debug_stat='off';

	//turn update checking in main window on/off
	$cfg_update_chk='off';

	//where is the server information file located
	$cfg_servers='servers.php';

	//allow visitors to register a mail account
	$cfg_visitor_reg='off';

	//version number
	$cfg_version_num='1.5';

?>