<html>
<head>
	<title>PHPXMail</title>
</head>
<frameset cols='200, *' border='0' frameborder='0'>
	<frame name='menu' src='menu.php' border='0' frameborder='0' scrolling='no'>
	<frame name='main' src='main.php' border='0' frameborder='0' scrolling='yes'>
</frameset>
</html>