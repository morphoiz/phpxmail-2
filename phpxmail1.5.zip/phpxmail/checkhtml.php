<html>

<head>
	<title>HTML check</title>
</head>

<body>

<?php echo stripslashes($_REQUEST['strHTML']); ?>

</body>
</html>