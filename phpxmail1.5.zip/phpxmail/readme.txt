					PHPXMail readme file

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
PhpXmail is a web based management software for the Xmail mail server written in php.

It's main usage is as a GUI (Graphic User Interface) to the Xmail administration extensions.

It allows the administrator of the mail server to perform configuration management and
monitoring tasks for the mail server. 

It allows the postmaster for each domain the Xmail server is configured to perform management functions.

It allows the users who have a mail account to manage their account settings.


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
INSTALLATION : 

see INSTALL.TXT file


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
LICENSING :

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
CREDITS :

Built upon Xmail Web Admin (XWA) by Paul Heijman, xmail@diggie.nl ,
based on XMail WAI by Michal A. Valasek, michal.valasek@altair2000.net


Written by Vlad Alexa Mancini